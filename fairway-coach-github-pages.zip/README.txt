Fairway Coach - iPhone PWA

Upload all files in this folder to the root of your GitHub Pages repository.
Then enable Settings > Pages > Deploy from branch > main > /(root).
